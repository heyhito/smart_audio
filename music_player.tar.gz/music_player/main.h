#ifndef __MAIN_H
#define __MAIN_H
#include <sys/select.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include "select.h"
#include "device.h"
#include "player.h"
#include "link.h"
#include "socket.h"

#endif

